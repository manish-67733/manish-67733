<?php
if(isset($_POST['submit'])){
$con=new mysqli('localhost','root','','crud opration');


$name=$_POST['Name'];
$email=$_POST['Email'];
$mobile=$_POST['Phone'];
$msg=$_POST['Massage'];
if($con){
    // echo "connection successfull";
}



    $sql="insert into suraj(name,email,phone,massage)values('$name','$email','$mobile','$msg')";
    $result=mysqli_query($con,$sql);
    if($result){
       echo "data inserted successfully";
      header("location:index.html");
    }else{
      die(mysqli_error($con));
    }
}
?>