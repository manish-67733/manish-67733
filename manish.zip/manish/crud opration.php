<?php
include'user.php';
if(isset($_POST['submit'])){
  $id=$_POST['id'];
  $name=$_POST['name'];
  $email=$_POST['email'];
  $mobile=$_POST['mobile'];
  $password=$_POST['password'];

    $sql="insert into crud(name,email,mobile,password)values('$name','$email','$mobile','$password')";
    $result=mysqli_query($con,$sql);
    if($result){
      // echo "data inserted successfully";
      header("location:display.php");
    }else{
      die(mysqli_error($con));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container">
    <form method="post">
<div class="form group">
    <label>name</label>
    <input type="text" class="form-control" 
  placeholder="enter your name" name="name"  autocomplete="off">
</div>
<div class="form group">
    <label>email</label>
    <input type="text" class="form-control" 
  placeholder="enter your email" name="email"  autocomplete="off">
</div>
<div class="form group">
    <label>mobile</label>
    <input type="text" class="form-control" 
  placeholder="enter your mobile number" name="mobile"  autocomplete="off">
  <div class="form group">
    <label>password</label>
    <input type="text" class="form-control" 
  placeholder="enter your password" name="password">
</div>
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>
</div>
</body>
</html>